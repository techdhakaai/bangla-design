import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import { AIOrchestrator } from "./agents/orchestrator";

export interface Env {
  DB: D1Database;
  STORAGE: R2Bucket;
  KV: KVNamespace;
  AI_ORCHESTRATOR: DurableObjectNamespace<AIOrchestrator>;
  OPENAI_API_KEY: string;
  ALLOWED_ORIGINS: string; // ✅ Fixed: was hardcoded before
}

const app = new Hono<{ Bindings: Env }>();

// ✅ Fixed: Env validation middleware — fail fast before any request
app.use("*", async (c, next) => {
  if (!c.env.OPENAI_API_KEY) {
    return c.json({ error: "Server misconfigured: OPENAI_API_KEY is missing" }, 500);
  }
  await next();
});

// Middleware
app.use("*", logger());
app.use(
  "*",
  cors({
    // ✅ Fixed: reads from env var instead of hardcoded URL
    origin: (origin) => {
      const allowed = (process.env.ALLOWED_ORIGINS || "http://localhost:3000").split(",");
      return allowed.includes(origin) ? origin : allowed[0];
    },
    credentials: true,
  })
);

// ✅ New: Simple KV-based rate limiter (10 requests/min per IP)
app.use("/api/generate", async (c, next) => {
  const ip = c.req.header("CF-Connecting-IP") || "unknown";
  const key = `ratelimit:${ip}:${Math.floor(Date.now() / 60000)}`;
  const count = parseInt((await c.env.KV.get(key)) || "0");

  if (count >= 10) {
    return c.json({ error: "Rate limit exceeded. Please wait 1 minute." }, 429);
  }

  await c.env.KV.put(key, String(count + 1), { expirationTtl: 120 });
  await next();
});

// Health check
app.get("/", (c) =>
  c.json({
    status: "ok",
    message: "AI Builder API",
    version: "1.1.0",
  })
);

// Generate endpoint
app.post("/api/generate", async (c) => {
  const { prompt, projectId } = await c.req.json();

  if (!prompt || typeof prompt !== "string" || prompt.trim().length < 5) {
    return c.json({ error: "Prompt must be at least 5 characters" }, 400);
  }

  if (prompt.length > 2000) {
    return c.json({ error: "Prompt too long. Max 2000 characters." }, 400);
  }

  const sessionId = projectId || crypto.randomUUID();
  const id = c.env.AI_ORCHESTRATOR.idFromName(sessionId);
  const orchestrator = c.env.AI_ORCHESTRATOR.get(id);

  const stream = await orchestrator.generate(prompt.trim());

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
});

// Get project
app.get("/api/projects/:id", async (c) => {
  const id = c.req.param("id");
  const result = await c.env.DB.prepare("SELECT * FROM projects WHERE id = ?")
    .bind(id)
    .first();

  if (!result) return c.json({ error: "Not found" }, 404);

  return c.json({
    id: result.id,
    name: result.name,
    files: JSON.parse(result.files || "{}"),
    created_at: result.created_at,
  });
});

// Create project
app.post("/api/projects", async (c) => {
  const body = await c.req.json();
  const id = crypto.randomUUID();

  await c.env.DB.prepare(
    `INSERT INTO projects (id, name, description, files, created_at)
     VALUES (?, ?, ?, ?, datetime('now'))`
  )
    .bind(id, body.name || "Untitled", body.description || "", JSON.stringify(body.files || {}))
    .run();

  return c.json({ id, success: true }, 201);
});

// Update project files
app.put("/api/projects/:id", async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();

  await c.env.DB.prepare(
    `UPDATE projects SET files = ?, updated_at = datetime('now') WHERE id = ?`
  )
    .bind(JSON.stringify(body.files), id)
    .run();

  return c.json({ success: true });
});

// List recent projects
app.get("/api/projects", async (c) => {
  const results = await c.env.DB.prepare(
    "SELECT id, name, created_at FROM projects ORDER BY created_at DESC LIMIT 20"
  ).all();

  return c.json({ projects: results.results });
});

export { AIOrchestrator };
export default app;
