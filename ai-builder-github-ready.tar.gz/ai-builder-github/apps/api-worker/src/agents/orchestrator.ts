import { DurableObject } from "cloudflare:workers";
import OpenAI from "openai";

interface Env {
  OPENAI_API_KEY: string;
  DB: D1Database;
  STORAGE: R2Bucket;
}

const PLANNING_PROMPT = `You are an expert web architect. Analyze the user's request and create a detailed plan.

Output ONLY a JSON object with this structure:
{
  "components": ["List of React components needed"],
  "pages": ["List of pages"],
  "stateManagement": "Description of state management needed",
  "styling": "Tailwind CSS strategy - colors, responsive breakpoints",
  "dependencies": ["npm packages needed beyond React"],
  "layout": "Overall layout structure description"
}`;

const CODEGEN_PROMPT = `You are an expert React/TypeScript developer. Generate production-ready code.

RULES:
1. Use TypeScript with proper types (no 'any')
2. Use functional components with hooks
3. Style with Tailwind CSS classes only
4. Make components responsive (mobile-first)
5. Add proper error handling
6. Use semantic HTML with ARIA attributes
7. Use lucide-react for icons

OUTPUT FORMAT - Return ONLY valid JSON:
{
  "files": {
    "/src/App.tsx": "complete component code",
    "/src/components/ComponentName.tsx": "component code"
  },
  "dependencies": ["lucide-react"],
  "explanation": "Brief explanation of what was built"
}`;

const REVIEW_PROMPT = `You are a senior code reviewer. Review the generated code for issues.

Check for:
- TypeScript type safety (no implicit 'any')
- Missing error handling
- Accessibility issues (missing ARIA labels)
- Performance problems (missing keys in lists, etc.)
- Security issues (dangerouslySetInnerHTML, etc.)

Output ONLY a JSON object:
{
  "score": 85,
  "issues": ["list of issues found"],
  "fixes": { "/src/App.tsx": "corrected code if needed" },
  "approved": true
}`;

export class AIOrchestrator extends DurableObject {
  private openai: OpenAI;
  private env: Env;

  constructor(state: DurableObjectState, env: Env) {
    super(state, env);
    this.env = env;
    this.openai = new OpenAI({ apiKey: env.OPENAI_API_KEY });
  }

  async generate(prompt: string): Promise<ReadableStream> {
    const encoder = new TextEncoder();

    const sendEvent = (data: object) =>
      encoder.encode(`data: ${JSON.stringify(data)}\n\n`); // ✅ Fixed: proper SSE format

    return new ReadableStream({
      start: async (controller) => {
        try {
          // Step 1: Planning
          controller.enqueue(sendEvent({ type: "status", message: "🔄 Analyzing your requirements..." }));
          const plan = await this.createPlan(prompt);

          // Step 2: Code Generation
          controller.enqueue(sendEvent({ type: "status", message: "📝 Generating your website code..." }));
          const code = await this.generateCode(prompt, plan);

          // Step 3: Review (new agent)
          controller.enqueue(sendEvent({ type: "status", message: "🔍 Reviewing code quality..." }));
          const reviewed = await this.reviewCode(code);

          // Step 4: Save
          const projectId = crypto.randomUUID();
          await this.saveProject(projectId, reviewed);

          controller.enqueue(sendEvent({
            type: "complete",
            projectId,
            files: reviewed.files,
            explanation: code.explanation,
          }));

          controller.close();
        } catch (error) {
          console.error("Generation error:", error);
          controller.enqueue(sendEvent({ type: "error", message: (error as Error).message }));
          controller.close();
        }
      },
    });
  }

  private async createPlan(prompt: string): Promise<any> {
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o", // ✅ Fixed: use gpt-4o instead of deprecated gpt-4-turbo-preview
      messages: [
        { role: "system", content: PLANNING_PROMPT },
        { role: "user", content: prompt },
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });
    return JSON.parse(response.choices[0].message.content || "{}");
  }

  private async generateCode(prompt: string, plan: any): Promise<any> {
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o", // ✅ Fixed
      messages: [
        { role: "system", content: CODEGEN_PROMPT },
        {
          role: "user",
          content: `User request: ${prompt}\n\nArchitecture plan: ${JSON.stringify(plan, null, 2)}\n\nGenerate the complete code now.`,
        },
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 4000,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    // Add required boilerplate files
    result.files = {
      ...result.files,
      "/src/index.tsx": `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);`,
      "/src/styles.css": `@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}`,
      "/public/index.html": `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Generated Website</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
  <div id="root"></div>
</body>
</html>`,
    };

    return result;
  }

  private async reviewCode(code: any): Promise<any> {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: REVIEW_PROMPT },
          {
            role: "user",
            content: `Review this code:\n${JSON.stringify(code.files, null, 2)}`,
          },
        ],
        response_format: { type: "json_object" },
        temperature: 0.3,
        max_tokens: 2000,
      });

      const review = JSON.parse(response.choices[0].message.content || "{}");

      // If reviewer provided fixes, merge them
      if (review.fixes && Object.keys(review.fixes).length > 0) {
        return {
          ...code,
          files: { ...code.files, ...review.fixes },
          reviewScore: review.score,
        };
      }

      return { ...code, reviewScore: review.score };
    } catch {
      // Review is non-blocking — return original code if review fails
      return code;
    }
  }

  private async saveProject(projectId: string, code: any) {
    // Save metadata to D1
    await this.env.DB.prepare(
      `INSERT INTO projects (id, name, files, created_at) VALUES (?, ?, ?, datetime('now'))`
    )
      .bind(projectId, "Generated Project", JSON.stringify(code.files))
      .run();

    // Save files to R2 for larger payloads
    await this.env.STORAGE.put(
      `projects/${projectId}/files.json`,
      JSON.stringify(code.files),
      { httpMetadata: { contentType: "application/json" } }
    );
  }
}
