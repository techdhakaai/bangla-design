"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import { SandpackProvider, SandpackPreview } from "@codesandbox/sandpack-react";
import Editor from "@monaco-editor/react";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Send, Loader2, FileCode, Play, MessageSquare, Sparkles, AlertCircle } from "lucide-react";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8787";

interface StreamMessage {
  type: "status" | "complete" | "error";
  message?: string;
  projectId?: string;
  files?: Record<string, string>;
  explanation?: string;
}

// ✅ Fixed: Detect Monaco language from file extension
function getLanguage(path: string): string {
  if (path.endsWith(".css")) return "css";
  if (path.endsWith(".html")) return "html";
  if (path.endsWith(".json")) return "json";
  if (path.endsWith(".md")) return "markdown";
  if (path.endsWith(".js") || path.endsWith(".jsx")) return "javascript";
  return "typescript";
}

// ✅ Fixed: ErrorBoundary component
function ErrorFallback({ error }: { error: Error }) {
  return (
    <div className="h-full flex items-center justify-center text-red-400 p-8">
      <div className="text-center">
        <AlertCircle className="w-12 h-12 mx-auto mb-3" />
        <p className="font-medium">Preview Error</p>
        <p className="text-sm opacity-75 mt-1">{error.message}</p>
      </div>
    </div>
  );
}

export default function BuilderPage() {
  const { projectId } = useParams();
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [files, setFiles] = useState<Record<string, string>>({});
  const [activeFile, setActiveFile] = useState("/src/App.tsx");
  const [streamMessages, setStreamMessages] = useState<Array<{ text: string; isError: boolean }>>([]);
  const [explanation, setExplanation] = useState<string>("");

  useEffect(() => {
    if (projectId) {
      fetch(`${API_URL}/api/projects/${projectId}`)
        .then((res) => res.json())
        .then((data) => {
          if (data.files) {
            setFiles(data.files);
            // Set first file as active if App.tsx doesn't exist
            const firstKey = Object.keys(data.files)[0];
            if (firstKey && !data.files["/src/App.tsx"]) {
              setActiveFile(firstKey);
            }
          }
        })
        .catch(console.error);
    }
  }, [projectId]);

  const generate = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setStreamMessages([]);
    setExplanation("");

    try {
      const response = await fetch(`${API_URL}/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, projectId }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || "API request failed");
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split("\n").filter(Boolean);

          for (const line of lines) {
            // ✅ Fixed: parse proper SSE format (lines start with "data: ")
            if (!line.startsWith("data: ")) continue;
            try {
              const data: StreamMessage = JSON.parse(line.slice(6));

              if (data.type === "status" && data.message) {
                setStreamMessages((prev) => [...prev, { text: data.message!, isError: false }]);
              } else if (data.type === "complete" && data.files) {
                setFiles(data.files);
                setExplanation(data.explanation || "");
                // Set App.tsx as active after generation
                if (data.files["/src/App.tsx"]) setActiveFile("/src/App.tsx");
              } else if (data.type === "error" && data.message) {
                setStreamMessages((prev) => [...prev, { text: data.message!, isError: true }]);
              }
            } catch {
              // ignore malformed lines
            }
          }
        }
      }
    } catch (error) {
      setStreamMessages((prev) => [
        ...prev,
        { text: `Error: ${(error as Error).message}`, isError: true },
      ]);
    } finally {
      setIsGenerating(false);
    }
  };

  const updateFile = (path: string, content: string | undefined) => {
    if (content !== undefined) {
      setFiles((prev) => ({ ...prev, [path]: content }));
    }
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="h-14 border-b flex items-center px-4 gap-4 bg-card">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="font-semibold">AI Builder</span>
        </div>
        <Separator orientation="vertical" className="h-6" />
        <span className="text-muted-foreground text-sm truncate max-w-[200px]">
          {projectId ? `Project: ${String(projectId).slice(0, 8)}...` : "New Project"}
        </span>
      </header>

      <ResizablePanelGroup direction="horizontal" className="flex-1">
        {/* Chat Panel */}
        <ResizablePanel defaultSize={25} minSize={20} maxSize={35}>
          <div className="h-full flex flex-col border-r">
            <div className="p-4 border-b bg-muted/50">
              <h2 className="font-semibold flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                Chat
              </h2>
            </div>

            <ScrollArea className="flex-1 p-4">
              <div className="space-y-3">
                {streamMessages.length === 0 && (
                  <div className="text-muted-foreground text-sm space-y-2">
                    <p>Describe the website you want to build...</p>
                    <div className="p-3 bg-muted rounded-lg text-xs">
                      <p className="font-medium mb-1">Example prompts:</p>
                      <ul className="space-y-1 list-disc list-inside">
                        <li>Create a landing page for a coffee shop</li>
                        <li>Build a portfolio with hero, about, contact</li>
                        <li>SaaS pricing page with 3 tiers</li>
                      </ul>
                    </div>
                  </div>
                )}
                {streamMessages.map((msg, i) => (
                  <div
                    key={i}
                    className={`text-sm p-2 rounded ${
                      msg.isError
                        ? "bg-red-900/30 text-red-300 border border-red-800"
                        : "bg-muted"
                    }`}
                  >
                    {msg.text}
                  </div>
                ))}
                {explanation && (
                  <div className="text-sm p-3 bg-green-900/20 border border-green-800 rounded text-green-300">
                    ✅ {explanation}
                  </div>
                )}
              </div>
            </ScrollArea>

            <div className="p-4 border-t space-y-2">
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., Create a landing page for a coffee shop..."
                className="min-h-[100px] resize-none"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) generate();
                }}
              />
              <Button
                onClick={generate}
                disabled={isGenerating || !prompt.trim()}
                className="w-full"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Generate (⌘+Enter)
                  </>
                )}
              </Button>
            </div>
          </div>
        </ResizablePanel>

        <ResizableHandle />

        {/* Code Editor */}
        <ResizablePanel defaultSize={35} minSize={25}>
          <div className="h-full flex flex-col border-r">
            <div className="flex items-center gap-1 p-2 border-b bg-muted/50 overflow-x-auto">
              {Object.keys(files).length > 0 ? (
                Object.keys(files).map((path) => (
                  <button
                    key={path}
                    onClick={() => setActiveFile(path)}
                    className={`px-3 py-1.5 text-xs rounded-md flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                      activeFile === path
                        ? "bg-background text-foreground shadow-sm border"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted"
                    }`}
                  >
                    <FileCode className="w-3 h-3" />
                    {path.split("/").pop()}
                  </button>
                ))
              ) : (
                <span className="text-xs text-muted-foreground px-2">No files yet</span>
              )}
            </div>

            <div className="flex-1">
              {files[activeFile] ? (
                <Editor
                  height="100%"
                  language={getLanguage(activeFile)} // ✅ Fixed: dynamic language
                  theme="vs-dark"
                  value={files[activeFile]}
                  onChange={(value) => updateFile(activeFile, value)}
                  options={{
                    minimap: { enabled: false },
                    fontSize: 13,
                    wordWrap: "on",
                    automaticLayout: true,
                    scrollBeyondLastLine: false,
                    lineNumbers: "on",
                  }}
                />
              ) : (
                <div className="h-full flex items-center justify-center text-muted-foreground">
                  <div className="text-center">
                    <FileCode className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>Generated code will appear here</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </ResizablePanel>

        <ResizableHandle />

        {/* Preview */}
        <ResizablePanel defaultSize={40} minSize={30}>
          <div className="h-full flex flex-col">
            <div className="p-2 border-b bg-muted/50 flex items-center gap-2">
              <Play className="w-4 h-4" />
              <span className="text-sm font-medium">Live Preview</span>
            </div>
            <div className="flex-1 bg-white overflow-hidden">
              {Object.keys(files).length > 0 ? (
                <SandpackProvider
                  template="react-ts"
                  files={files}
                  options={{
                    externalResources: ["https://cdn.tailwindcss.com"],
                    autoReload: true,
                    recompileMode: "delayed",
                    recompileDelay: 500,
                  }}
                >
                  <SandpackPreview
                    style={{ height: "100%" }}
                    showOpenInCodeSandbox={false}
                    showRefreshButton={true}
                  />
                </SandpackProvider>
              ) : (
                <div className="h-full flex items-center justify-center text-muted-foreground bg-background">
                  <div className="text-center">
                    <Play className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>Preview will appear here</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}
